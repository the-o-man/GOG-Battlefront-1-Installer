#!/bin/bash
python3 apt_status.py &
process=$!
echo $process
pkexec apt -y update && sudo apt -y upgrade && sudo apt -y install python3 python3-pip wine winetricks && sudo kill $process
